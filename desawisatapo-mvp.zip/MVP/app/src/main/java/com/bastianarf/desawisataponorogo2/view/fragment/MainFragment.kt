package com.bastianarf.desawisataponorogo2.view.fragment

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.bastianarf.desawisataponorogo2.adapters.MainAdapter
import com.bastianarf.desawisataponorogo2.databinding.FragmentMainBinding
import com.bastianarf.desawisataponorogo2.presenter.MainFragmentPresenter
import com.bastianarf.desawisataponorogo2.utilities.Content
import com.bastianarf.desawisataponorogo2.view.contract.MainFragmentContract

class MainFragment : Fragment(), MainFragmentContract.View {

    private var _binding: FragmentMainBinding? = null
    private val binding get() = _binding!!

    private lateinit var presenter: MainFragmentPresenter
    private lateinit var mainAdapter: MainAdapter
    private val contents = mutableListOf<Content>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMainBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        presenter = MainFragmentPresenter(this)

        val recyclerViewContent = binding.rvMain
        recyclerViewContent.layoutManager = LinearLayoutManager(context)
        mainAdapter = MainAdapter(requireContext(), contents)
        recyclerViewContent.adapter = mainAdapter

        presenter.loadContents()
    }

    override fun showContents(contents: List<Content>) {
        this.contents.clear()
        this.contents.addAll(contents)
        mainAdapter.notifyDataSetChanged()
    }

    fun searchContents(query: String) {
        presenter.searchContents(query)
    }

    fun filterContents(category: String) {
        presenter.loadContents()  // Reload all contents before applying filter
        if (category.isNotEmpty()) {
            presenter.filterContents(category)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        Log.d("MainFragment", "onDestroyView called")
        _binding = null
    }
}
