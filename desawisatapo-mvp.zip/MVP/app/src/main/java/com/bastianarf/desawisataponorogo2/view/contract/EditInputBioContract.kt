package com.bastianarf.desawisataponorogo2.view.contract

import com.bastianarf.desawisataponorogo2.utilities.UserProfileResponse
import java.io.File

interface EditInputBioContract {
    interface View {
        fun showLoading()
        fun hideLoading()
        fun showUploadSuccess(message: String, photoUrl: String?)
        fun showUploadFailure(message: String)
        fun showProfile(userProfile: UserProfileResponse)
        fun enableSaveButton(isEnabled: Boolean)
        fun showToast(message: String)
        fun goToMainActivity()
    }

    interface Presenter {
        fun start()
        fun uploadImage(file: File, onSuccess: (String) -> Unit, onFailure: () -> Unit)
        fun getUserProfile()
        fun saveProfile(email: String, fullName: String, nickName: String, bio: String, file: File)
    }
}


