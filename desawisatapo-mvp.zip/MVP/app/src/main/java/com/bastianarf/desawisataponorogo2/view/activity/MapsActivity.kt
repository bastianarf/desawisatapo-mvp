package com.bastianarf.desawisataponorogo2.view.activity

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Resources
import android.os.Bundle
import android.util.Log
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bastianarf.desawisataponorogo2.R
import com.bastianarf.desawisataponorogo2.databinding.ActivityMapsBinding
import com.bastianarf.desawisataponorogo2.utilities.Content
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MapStyleOptions
import com.google.android.gms.maps.model.MarkerOptions
import com.google.firebase.firestore.FirebaseFirestore
import java.util.regex.Pattern

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMapsBinding
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var firestore: FirebaseFirestore
    private lateinit var contents: MutableList<Content>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        firestore = FirebaseFirestore.getInstance()

        setupContents()
    }

    private fun setupContents() {
        firestore.collection("contents").get().addOnSuccessListener { result ->
            contents = result.documents.map { document ->
                val content = document.toObject(Content::class.java)!!
                content.documentId= document.id
                content
            }.toMutableList()
            showMarkers(contents)
        }
    }

    private fun showMarkers(contents: MutableList<Content>) {
        contents.forEach { content ->
            val mapsLink = content.mapsLink
            val latLng = getLatLngFromMapsLink(mapsLink)
            if (latLng != null) {
                val marker = mMap.addMarker(MarkerOptions().position(latLng).snippet(content.categories).title(content.name))
                marker?.tag = content
            }
        }
        mMap.setOnMarkerClickListener { marker ->
            marker.showInfoWindow()
            true
        }

        mMap.setOnInfoWindowClickListener { marker ->
            val content = marker.tag as? Content
            content?.let {
                openDetailActivity(it)
            }
        }
    }

   /* private fun handleMarkerClick(marker: Marker) {
        val gestureDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                val content = marker.tag as? Content
                content?.let {
                    openDetailActivity(it)
                }
                return true
            }
        })

        mMap.setOnMapClickListener { latLng ->
            // Convert LatLng to MotionEvent if necessary or handle the event directly
            // Here, just passing a dummy MotionEvent for demonstration purposes
            val event = MotionEvent.obtain(0,0, MotionEvent.ACTION_DOWN, latLng.latitude.toFloat(), latLng.longitude.toFloat(),0)
            gestureDetector.onTouchEvent(event)
        }
    }*/

    private fun openDetailActivity(content: Content) {
        val intent = Intent(this, DetailActivity::class.java)
        intent.putExtra("documentId", content.documentId)
        startActivity(intent)
    }
    private fun getLatLngFromMapsLink(mapsLink: String): LatLng? {
        val pattern = Pattern.compile("@(.*?),(.*?),")
        val matcher = pattern.matcher(mapsLink)
        return if (matcher.find()) {
            val lat = matcher.group(1)?.toDoubleOrNull()
            val lng = matcher.group(2)?.toDoubleOrNull()
            if (lat != null && lng != null) LatLng(lat, lng) else null
        } else {
            null
        }
    }

    private fun setMapStyle() {
        try {
            val success =
                mMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(this, R.raw.map_style))
            if (!success) {
                Log.e(ContentValues.TAG, "Style parsing failed")
            }
        } catch (exception: Resources.NotFoundException) {
            Log.e(ContentValues.TAG, "Can't find style. Error : ", exception)
        }
    }

    override fun onMapReady(p0: GoogleMap) {
        mMap = p0

        mMap.uiSettings.isZoomControlsEnabled = true
        mMap.uiSettings.isIndoorLevelPickerEnabled = true
        mMap.uiSettings.isCompassEnabled = true
        mMap.uiSettings.isMapToolbarEnabled = true

        setMapStyle()
        getMyLocation()
    }

    private val requestPermissionLauncher =
        registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { isGranted: Boolean ->
            if (isGranted) {
                getMyLocation()
            }
        }

    private fun getMyLocation() {
        if (ContextCompat.checkSelfPermission(this.applicationContext, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            Log.d("TYSA","Bener nih")
            mMap.isMyLocationEnabled = true
            fusedLocationClient.lastLocation.addOnSuccessListener { location ->
                if (location != null) {
                    val currentLatLng = LatLng(location.latitude, location.longitude)
                    Log.d("TYSI",currentLatLng.toString())
                    mMap.addMarker(
                        MarkerOptions().position(currentLatLng).snippet("Tes tes").title("Lokasi Saya")
                    )
                    mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 20f))
                }
            }
        } else {
            requestPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
            Log.d("TYS","Salah nih")
        }
    }

    companion object {

        @JvmStatic
        fun start(context: Context) {
            val starter = Intent(context, MapsActivity::class.java)
            context.startActivity(starter)
        }
    }
}