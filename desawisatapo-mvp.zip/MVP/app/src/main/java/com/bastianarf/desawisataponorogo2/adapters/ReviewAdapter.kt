package com.bastianarf.desawisataponorogo2.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bastianarf.desawisataponorogo2.R
import com.bastianarf.desawisataponorogo2.utilities.Review
import com.bumptech.glide.Glide

class ReviewAdapter(private val context: Context?, private var reviews: MutableList<Review>) : RecyclerView.Adapter<ReviewAdapter.ViewHolder>() {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var fullNameTV: TextView = itemView.findViewById(R.id.tv_rvw_fullName)
        val reviewTextTV: TextView = itemView.findViewById(R.id.tv_rvw_review)
        val avatarImage: ImageView = itemView.findViewById(R.id.iv_rvw_user)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.item_review, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val review = reviews[position]
        holder.fullNameTV.text = review.fullName
        holder.reviewTextTV.text = review.reviewText

        // Load avatar image
        if (!review.avatar.isNullOrEmpty()) {
            Glide.with(context!!)
                .load(review.avatar)
                .into(holder.avatarImage)
        } else {
            holder.avatarImage.setImageResource(R.drawable.ic_baseline_person_24) // Fallback avatar
        }
    }

    override fun getItemCount(): Int {
        return reviews.size
    }

    fun updateList(newReviews: MutableList<Review>) {
        reviews.clear()
        reviews.addAll(newReviews)
        notifyDataSetChanged()
    }
}
