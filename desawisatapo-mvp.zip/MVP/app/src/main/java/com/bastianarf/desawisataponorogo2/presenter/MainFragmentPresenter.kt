package com.bastianarf.desawisataponorogo2.presenter

import android.util.Log
import com.bastianarf.desawisataponorogo2.utilities.Content
import com.bastianarf.desawisataponorogo2.view.contract.MainFragmentContract
import com.google.firebase.firestore.FirebaseFirestore

class MainFragmentPresenter(private val view: MainFragmentContract.View) : MainFragmentContract.Presenter {
    private val db = FirebaseFirestore.getInstance()

    override fun loadContents() {
        db.collection("contents").limit(60).get()
            .addOnSuccessListener { documents ->
                val contents = documents.map { document ->
                    val content = document.toObject(Content::class.java)
                    content.documentId = document.id
                    content
                }
                view.showContents(contents)
            }
            .addOnFailureListener { exception ->
                Log.d("MainFragment", "Error getting documents : ", exception)
            }
    }



    override fun searchContents(query: String) {
        val endQuery = query + "\uf8ff"
        db.collection("contents")
            .whereGreaterThanOrEqualTo("name", query)
            .whereLessThanOrEqualTo("name", endQuery)
            .get()
            .addOnSuccessListener { documents ->
                val searchResults = documents.map { document ->
                    val content = document.toObject(Content::class.java)
                    content.documentId = document.id
                    content
                }
                view.showContents(searchResults)
            }
            .addOnFailureListener { exception ->
                Log.d("MainFragment", "Error getting documents : ", exception)
            }
    }

    override fun filterContents(category: String) {
        db.collection("contents")
            .whereEqualTo("categories", category)
            .get()
            .addOnSuccessListener { documents ->
                val filteredResults = mutableListOf<Content>()
                for (document in documents) {
                    val content = document.toObject(Content::class.java)
                    content.documentId = document.id
                    filteredResults.add(content)
                }
                view?.showContents(filteredResults)
            }
            .addOnFailureListener { exception ->
                Log.d("MainFragment", "Error getting documents : ", exception)
             }
    }
}
