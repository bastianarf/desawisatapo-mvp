package com.bastianarf.desawisataponorogo2.view.contract

import com.bastianarf.desawisataponorogo2.utilities.Review

interface DetailContract {

    interface View {
        fun showTitle(title: String)
        fun showFavorite(isFavorite: Boolean)
        fun showToast(message: String)
        fun updateFavoriteIcon()
        fun showCategories(categories: String)
        fun setCategoryBackground(category: String)
        fun showDescription(description: String)
        fun loadYoutubeVideo(videoId: String?)
        fun loadCarousel(imageLinks: List<String>)
        fun showReviews(reviews: List<Review>)
        fun showEmptyReviews()
        fun showDummyReviewItem(reviewItem: Map<String, String>)
    }

    interface Presenter {
        fun onCreate(documentId: String?)
        fun onFavoriteClicked()
        fun fetchReviews()
        fun addReview(reviewText: String)
        fun addDummyReviewItem()
    }
}


