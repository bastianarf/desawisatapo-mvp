package com.bastianarf.desawisataponorogo2.view.contract

interface MainContract {
    interface View {
        fun showUserNickName(nickName: String)
    }

    interface Presenter {
        fun loadUserNickName()
    }
}
