package com.bastianarf.desawisataponorogo2.presenter

import com.bastianarf.desawisataponorogo2.utilities.UserProfileResponse
import com.bastianarf.desawisataponorogo2.view.contract.UserContract
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class UserPresenter(private val auth: FirebaseAuth, private val db: FirebaseFirestore) : UserContract.Presenter {

    private var view: UserContract.View? = null

    override fun attachView(view: UserContract.View) {
        this.view = view
    }

    override fun detachView() {
        view = null
    }

    override fun getUserProfile() {
        val userId = auth.currentUser?.uid
        if (userId != null) {
            db.collection("users")
                .document(userId)
                .get()
                .addOnSuccessListener { documentSnapshot ->
                    if (documentSnapshot != null && documentSnapshot.exists()) {
                        val userProfile = documentSnapshot.toObject(UserProfileResponse::class.java)
                        view?.showUserProfile(userProfile)
                    } else {
                        view?.showError("User profile not found")
                    }
                }
                .addOnFailureListener { exception ->
                    view?.showError("Error fetching user profile: $exception")
                }
        } else {
            view?.showError("User not logged in")
        }
    }

    override fun signOut() {
        auth.signOut()
        view?.showUserProfile(null)
    }
}
