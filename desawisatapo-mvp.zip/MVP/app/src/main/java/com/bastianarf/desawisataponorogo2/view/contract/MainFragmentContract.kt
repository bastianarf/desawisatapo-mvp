package com.bastianarf.desawisataponorogo2.view.contract

import com.bastianarf.desawisataponorogo2.utilities.Content

interface MainFragmentContract {
    interface View {
        fun showContents(contents: List<Content>)
    }

    interface Presenter {
        fun loadContents()
        fun searchContents(query: String)
        fun filterContents(category: String)
    }
}
