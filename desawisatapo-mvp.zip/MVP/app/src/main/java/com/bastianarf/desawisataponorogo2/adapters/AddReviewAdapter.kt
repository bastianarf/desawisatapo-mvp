package com.bastianarf.desawisataponorogo2.adapters

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bastianarf.desawisataponorogo2.R
import com.bastianarf.desawisataponorogo2.customview.MyReviewEditText
import com.bumptech.glide.Glide
import com.google.firebase.firestore.FirebaseFirestore
import de.hdodenhof.circleimageview.CircleImageView

class AddReviewAdapter(private val addReviewListener: (String) -> Unit) : RecyclerView.Adapter<AddReviewAdapter.ReviewViewHolder>() {

    private val reviews = mutableListOf<Map<String, Any>>()
    private val firestore = FirebaseFirestore.getInstance()

    fun addReviewItem(review: Map<String, Any>) {
        reviews.add(review)
        notifyItemInserted(reviews.size - 1)
    }
    fun setReviews(reviews: List<Map<String, Any>>) {
        this.reviews.clear()
        this.reviews.addAll(reviews)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ReviewViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_add_review, parent, false)
        return ReviewViewHolder(view)
    }

    override fun onBindViewHolder(holder: ReviewViewHolder, position: Int) {
        val review = reviews[position]
        holder.bind(review)
    }

    override fun getItemCount(): Int = reviews.size

    inner class ReviewViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        private val ivUser: CircleImageView = itemView.findViewById(R.id.iv_rvw_user)
        private val tvName: TextView = itemView.findViewById(R.id.tv_rvw_fullName)
        private val addReviewEditText: MyReviewEditText = itemView.findViewById(R.id.tv_add_review)


        fun bind(review: Map<String, Any>) {
            val userId = review["userId"] as String

            // Fetch user details from Firestore
            firestore.collection("users").document(userId).get()
                .addOnSuccessListener { document ->
                    val fullName = document.getString("fullName")
                    val avatar = document.getString("avatar")

                    // Bind user details to the views
                    tvName.text = fullName
                    Glide.with(ivUser.context)
                        .load(avatar)
                        .into(ivUser)
                }
                .addOnFailureListener { e ->
                    Log.w("AddReviewAdapter", "Error fetching user data", e)
                }
            addReviewEditText.setSendButtonClickListener(object: MyReviewEditText.SendButtonClickListener {
                override fun onSendButtonClick(text: String) {
                    addReviewListener(text)
                }
            })
        }
    }
}