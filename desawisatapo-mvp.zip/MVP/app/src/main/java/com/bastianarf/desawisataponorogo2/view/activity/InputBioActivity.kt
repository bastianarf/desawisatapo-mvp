package com.bastianarf.desawisataponorogo2.view.activity

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.widget.addTextChangedListener
import com.bastianarf.desawisataponorogo2.R
import com.bastianarf.desawisataponorogo2.databinding.ActivityInputBioBinding
import com.bastianarf.desawisataponorogo2.presenter.InputBioPresenter
import com.bastianarf.desawisataponorogo2.utilities.createCustomTempFile
import com.bastianarf.desawisataponorogo2.utilities.reduceFileImage
import com.bastianarf.desawisataponorogo2.utilities.rotateImage
import com.bastianarf.desawisataponorogo2.utilities.uriToFile
import com.bastianarf.desawisataponorogo2.view.contract.InputBioContract
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import java.io.File
import java.io.FileOutputStream

// InputBioActivity.kt
class InputBioActivity : AppCompatActivity(), InputBioContract.View {
    private lateinit var binding: ActivityInputBioBinding
    private lateinit var currentPhotoPath: String
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore
    private lateinit var storage: FirebaseStorage
    private lateinit var presenter: InputBioContract.Presenter
    private var getFile: File? = null

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (!allPermissionsGranted()) {
                Toast.makeText(
                    this, R.string.unauthorized_perm,
                    Toast.LENGTH_SHORT
                ).show()
                finish()
            }
        }
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityInputBioBinding.inflate(layoutInflater)
        setContentView(binding.root)

        firestore = FirebaseFirestore.getInstance()
        firebaseAuth = FirebaseAuth.getInstance()
        storage = FirebaseStorage.getInstance()

        presenter = InputBioPresenter(this, firestore, firebaseAuth, storage)

        if (!allPermissionsGranted()) {
            ActivityCompat.requestPermissions(
                this, REQUIRED_PERMISSIONS, REQUEST_CODE_PERMISSIONS
            )
        }

        binding.apply {
            btnCamera.setOnClickListener { startTakePhoto() }
            btnGallery.setOnClickListener { startGallery() }
            buttonAdd.setOnClickListener { uploadImage() }
            buttonAdd.isEnabled = false

            edAddBio.addTextChangedListener {
                val isBioEmpty = it.isNullOrEmpty()
                val isImageSelected = getFile != null
                buttonAdd.isEnabled = !isBioEmpty && isImageSelected
            }
        }

        presenter.start()
    }

    private fun startGallery() {
        val intent = Intent()
        intent.action = Intent.ACTION_GET_CONTENT
        intent.type = "image/*"
        val chooser = Intent.createChooser(intent, "Pilih Gambar")
        launcherIntentGallery.launch(chooser)
    }

    private fun startTakePhoto() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        intent.resolveActivity(packageManager)

        createCustomTempFile(application).also {
            val photoURI: Uri = FileProvider.getUriForFile(this@InputBioActivity, "com.bastianarf.desawisataponorogo2", it)
            currentPhotoPath = it.absolutePath
            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
            launcherIntentCamera.launch(intent)
        }
    }

    private val launcherIntentCamera = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (it.resultCode == RESULT_OK) {
            val myFile = File(currentPhotoPath)
            myFile.let { file ->
                val bitmap = BitmapFactory.decodeFile(file.path)
                rotateImage(bitmap, currentPhotoPath).compress(
                    Bitmap.CompressFormat.JPEG,
                    100,
                    FileOutputStream(file)
                )
                setFile(file)
            }
        }
    }

    private val launcherIntentGallery = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val selectedImg = result.data?.data as Uri

            selectedImg.let { uri ->
                val myFile = uriToFile(uri, this)
                setFile(myFile)
            }
        }
    }

    private fun uploadImage() {
        if (getFile != null) {
            val bio = binding.edAddBio.text.toString()
            val file = reduceFileImage(getFile as File)
            val user = firebaseAuth.currentUser

            user?.let {
                presenter.uploadImage(it.uid, file, bio)
            }
        }
    }

    private fun setFile(file: File) {
        getFile = file
        presenter.setFile(file)
        // Enable the button if the bio is not empty
        binding.buttonAdd.isEnabled = !binding.edAddBio.text.isNullOrEmpty()
    }

    private fun goToMainActivity() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish()
    }

    override fun showUploadSuccess() {
        AlertDialog.Builder(this).apply {
            setTitle("Upload Successful")
            setMessage("Profile updated successfully")
            setPositiveButton("Ok") { _, _ ->
                goToMainActivity()
                finish()
            }
            create()
            show()
        }
    }

    override fun showUploadFailure(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun showLoading(isLoading: Boolean) {
        binding.buttonAdd.isEnabled = !isLoading
    }

    override fun setThumbnailImage(file: File) {
        binding.ivThumbnail.setImageBitmap(BitmapFactory.decodeFile(file.path))
    }

    override fun resetThumbnailImage() {
        binding.ivThumbnail.setImageResource(R.drawable.ic_thumbnail_image)
    }

    companion object {
        private val REQUIRED_PERMISSIONS = arrayOf(Manifest.permission.CAMERA)
        private const val REQUEST_CODE_PERMISSIONS = 10

        @JvmStatic
        fun start(context: Context) {
            val starter = Intent(context, InputBioActivity::class.java)
            context.startActivity(starter)
        }
    }
}
