package com.bastianarf.desawisataponorogo2.view.fragment

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.bastianarf.desawisataponorogo2.R
import com.bastianarf.desawisataponorogo2.presenter.UserPresenter
import com.bastianarf.desawisataponorogo2.databinding.FragmentUserBinding
import com.bastianarf.desawisataponorogo2.utilities.UserProfileResponse
import com.bastianarf.desawisataponorogo2.view.activity.EditInputBioActivity
import com.bastianarf.desawisataponorogo2.view.activity.LoginActivity
import com.bastianarf.desawisataponorogo2.view.contract.UserContract
import com.bumptech.glide.Glide
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase

// UserFragment.kt
class UserFragment : Fragment(), UserContract.View {

    private var _binding: FragmentUserBinding? = null
    private val binding get() = _binding!!

    private lateinit var presenter: UserContract.Presenter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentUserBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Initialize the presenter
        presenter = UserPresenter(Firebase.auth, FirebaseFirestore.getInstance())
        presenter.attachView(this)

        presenter.getUserProfile()
    }

    override fun showUserProfile(userProfile: UserProfileResponse?) {
        if (userProfile != null) {
            binding.tvFullName.text = resources.getString(R.string.profile_fullname, userProfile.fullName)
            binding.tvNickName.text = resources.getString(R.string.profile_nickname, userProfile.nickName)
            binding.tvEmail.text = resources.getString(R.string.profile_email, userProfile.email)
            binding.tvBio.text = resources.getString(R.string.profile_bio, userProfile.bio)
            Glide.with(requireContext())
                .load(userProfile.avatar)
                .into(binding.userAvatar)

            binding.btnEditProfile.setOnClickListener {
                val intent = Intent(requireContext(), EditInputBioActivity::class.java)
                startActivity(intent)
            }

            binding.btnLogout.setOnClickListener {
                presenter.signOut()
            }
        } else {
            // Handle the case where the user is signed out
            val intent = Intent(requireContext(), LoginActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            requireActivity().finish()
        }
    }

    override fun showError(message: String) {
        // Show error message to the user
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        presenter.detachView()
        _binding = null
    }
}
