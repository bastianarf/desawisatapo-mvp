package com.bastianarf.desawisataponorogo2.view.contract

import com.bastianarf.desawisataponorogo2.utilities.UserProfileResponse

interface UserContract {
    interface View {
        fun showUserProfile(userProfile: UserProfileResponse?)
        fun showError(message: String)
    }

    interface Presenter {
        fun attachView(view: View)
        fun detachView()
        fun getUserProfile()
        fun signOut()
    }
}