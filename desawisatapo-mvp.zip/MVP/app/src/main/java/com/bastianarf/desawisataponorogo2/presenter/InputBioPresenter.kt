package com.bastianarf.desawisataponorogo2.presenter

import android.net.Uri
import com.bastianarf.desawisataponorogo2.view.contract.InputBioContract
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import java.io.File

class InputBioPresenter(
    private val view: InputBioContract.View,
    private val firestore: FirebaseFirestore,
    private val firebaseAuth: FirebaseAuth,
    private val storage: FirebaseStorage
) : InputBioContract.Presenter {

    private var storageRef: StorageReference = storage.reference
    private var currentFile: File? = null

    override fun uploadImage(userId: String, file: File, bio: String) {
        view.showLoading(true)
        val fileRef = storageRef.child("avatar/${file.name}")
        val uri = Uri.fromFile(file)

        fileRef.putFile(uri)
            .addOnSuccessListener {
                fileRef.downloadUrl.addOnSuccessListener { downloadUri ->
                    val userBioData = hashMapOf(
                        "bio" to bio,
                        "avatar" to downloadUri.toString()
                    )

                    firestore.collection("users").document(userId)
                        .set(userBioData, SetOptions.merge())
                        .addOnSuccessListener {
                            view.showUploadSuccess()
                            view.showLoading(false)
                        }
                        .addOnFailureListener { e ->
                            view.showUploadFailure(e.message ?: "Unknown error occurred")
                            view.showLoading(false)
                        }
                }.addOnFailureListener { e ->
                    view.showUploadFailure(e.message ?: "Unknown error occurred")
                    view.showLoading(false)
                }
            }
            .addOnFailureListener { e ->
                view.showUploadFailure(e.message ?: "Unknown error occurred")
                view.showLoading(false)
            }
    }

    override fun setFile(file: File) {
        currentFile = file
        view.setThumbnailImage(file)
    }

    override fun start() {
        currentFile?.let {
            view.setThumbnailImage(it)
        } ?: view.resetThumbnailImage()
    }
}
