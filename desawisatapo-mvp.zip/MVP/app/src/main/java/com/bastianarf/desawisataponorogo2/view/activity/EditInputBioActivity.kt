package com.bastianarf.desawisataponorogo2.view.activity
import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.widget.addTextChangedListener
import com.bastianarf.desawisataponorogo2.databinding.ActivityEditInputBioBinding
import com.bastianarf.desawisataponorogo2.presenter.EditInputBioPresenter
import com.bastianarf.desawisataponorogo2.utilities.UserProfileResponse
import com.bastianarf.desawisataponorogo2.utilities.createCustomTempFile
import com.bastianarf.desawisataponorogo2.utilities.rotateImage
import com.bastianarf.desawisataponorogo2.utilities.uriToFile
import com.bastianarf.desawisataponorogo2.view.contract.EditInputBioContract
import com.bumptech.glide.Glide
import com.google.firebase.auth.FirebaseAuth
import java.io.File
import java.io.FileOutputStream

class EditInputBioActivity : AppCompatActivity(), EditInputBioContract.View {
    private lateinit var binding: ActivityEditInputBioBinding
    private lateinit var presenter: EditInputBioContract.Presenter
    private lateinit var currentPhotoPath: String
    private var getFile: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditInputBioBinding.inflate(layoutInflater)
        setContentView(binding.root)

        presenter = EditInputBioPresenter(this)

        if (!allPermissionsGranted()) {
            ActivityCompat.requestPermissions(
                this,
                REQUIRED_PERMISSIONS,
                REQUEST_CODE_PERMISSIONS
            )
        }

        setupListeners()
        presenter.start()
    }

    override fun showLoading() {
        // Implement loading indicator
    }

    override fun hideLoading() {
        // Hide loading indicator
    }

    override fun showUploadSuccess(message: String, photoUrl: String?) {
        if (isFinishing || isDestroyed) {
            return
        }
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        photoUrl?.let {
            Glide.with(this).load(it).into(binding.ivThumbnail)
        }
    }

    override fun showUploadFailure(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun showProfile(userProfile: UserProfileResponse) {
        binding.inputFullName.setText(userProfile.fullName)
        binding.inputNickName.setText(userProfile.nickName)
        binding.inputBio.setText(userProfile.bio)
        if (!userProfile.avatar.isNullOrEmpty()) {
            Glide.with(this).load(userProfile.avatar).into(binding.ivThumbnail)
        }
    }

    override fun enableSaveButton(isEnabled: Boolean) {
        binding.btnEditInput.isEnabled = isEnabled
    }

    override fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun goToMainActivity() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish()
    }

    private fun setupListeners() {
        binding.apply {
            btnCamera.setOnClickListener { startTakePhoto() }
            btnGallery.setOnClickListener { startGallery() }
            btnEditInput.setOnClickListener {
                val email = FirebaseAuth.getInstance().currentUser?.email.toString()
                val fullName = binding.inputFullName.text.toString()
                val nickName = binding.inputNickName.text.toString()
                val bio = binding.inputBio.text.toString()
                getFile?.let { file -> presenter.saveProfile(email, fullName, nickName, bio, file)
                } ?: run {
                    showToast("Please select an image")
                }
            }
            btnEditInput.isEnabled = false

            inputBio.addTextChangedListener {
                val isBioEmpty = it.isNullOrEmpty()
                val isImageSelected = getFile != null
                btnEditInput.isEnabled = !isBioEmpty && isImageSelected
            }
        }
    }

    private fun startGallery() {
        val intent = Intent()
        intent.action = Intent.ACTION_GET_CONTENT
        intent.type = "image/*"
        val chooser = Intent.createChooser(intent, "Pilih Gambar")
        launcherIntentGallery.launch(chooser)
    }

    private fun startTakePhoto() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        intent.resolveActivity(packageManager)

        createCustomTempFile(application).also {
            val photoURI: Uri = FileProvider.getUriForFile(this@EditInputBioActivity, "com.bastianarf.desawisataponorogo2", it)
            currentPhotoPath = it.absolutePath
            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
            launcherIntentCamera.launch(intent)
        }
    }

    private val launcherIntentCamera = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (it.resultCode == RESULT_OK) {
            val myFile = File(currentPhotoPath)
            myFile.let { file ->
                val bitmap = BitmapFactory.decodeFile(file.path)
                rotateImage(bitmap, currentPhotoPath).compress(
                    Bitmap.CompressFormat.JPEG,
                    100,
                    FileOutputStream(file)
                )
                setFile(file)
            }
        }
    }

    private val launcherIntentGallery = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val selectedImg = result.data?.data as Uri
            selectedImg.let { uri ->
                val myFile = uriToFile(uri, this)
                setFile(myFile)
            }
        }
    }

    private fun setFile(file: File){
        getFile = file
        enableSaveButton(!binding.inputBio.text.isNullOrEmpty())
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

    companion object {
        private val REQUIRED_PERMISSIONS = arrayOf(Manifest.permission.CAMERA)
        private const val REQUEST_CODE_PERMISSIONS = 10

        @JvmStatic
        fun start(context: Context) {
            val starter = Intent(context, EditInputBioActivity::class.java)
            context.startActivity(starter)
        }
    }
}
