package com.bastianarf.desawisataponorogo2.view.activity

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager.widget.ViewPager
import com.bastianarf.desawisataponorogo2.R
import com.bastianarf.desawisataponorogo2.adapters.ImageAdapter
import com.bastianarf.desawisataponorogo2.databinding.ActivityDetailBinding
import com.bastianarf.desawisataponorogo2.presenter.DetailPresenter
import com.bastianarf.desawisataponorogo2.utilities.Review
import com.bastianarf.desawisataponorogo2.view.contract.DetailContract
import com.bastianarf.desawisataponorogo2.view.fragment.DetailFragment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class DetailActivity : AppCompatActivity(), DetailContract.View {

    private lateinit var binding: ActivityDetailBinding
    private lateinit var presenter: DetailPresenter
    private var isFavorite = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        presenter = DetailPresenter(this, FirebaseFirestore.getInstance(), FirebaseAuth.getInstance())

        val documentId = intent.getStringExtra("documentId")
        presenter.onCreate(documentId)

        setupFragment(documentId)
    }

    private fun setupFragment(documentId: String?) {
        if (documentId != null) {
            val detailFragment = DetailFragment().apply {
                arguments = Bundle().apply {
                    putString("contentId", documentId)
                }
            }
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container_add_review, detailFragment)
                .commitNow()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.detail_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menu_favorite -> {
                presenter.onFavoriteClicked()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onPrepareOptionsMenu(menu: Menu?): Boolean {
        super.onPrepareOptionsMenu(menu)
        val favoriteItem = menu?.findItem(R.id.menu_favorite)
        favoriteItem?.setIcon(if (isFavorite) R.drawable.ic_baseline_favorite_24 else R.drawable.ic_baseline_favorite_border_24)
        return true
    }

    override fun showTitle(title: String) {
        supportActionBar?.title = title
    }

    override fun showFavorite(isFavorite: Boolean) {
        this.isFavorite = isFavorite
        invalidateOptionsMenu()
    }

    override fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun updateFavoriteIcon() {
        invalidateOptionsMenu()
    }

    override fun showCategories(categories: String) {
        binding.tvCategories.text = categories
    }

    override fun setCategoryBackground(category: String) {
        when (category) {
            "Wisata Alam" -> binding.tvCategories.setBackgroundResource(R.color.green_500)
            "Wisata Budaya" -> binding.tvCategories.setBackgroundResource(R.color.red_500)
            "Wisata Buatan" -> binding.tvCategories.setBackgroundResource(R.color.blue_500)
            "Wisata Religi" -> binding.tvCategories.setBackgroundResource(R.color.gray_500)
            "Desa Wisata" -> binding.tvCategories.setBackgroundResource(R.color.brown_500)
        }
    }

    override fun showDescription(description: String) {
        binding.tvItemDescription.text = description
    }

    override fun loadYoutubeVideo(videoId: String?) {
        val webSettings = binding.youtubeWebview.settings
        webSettings.javaScriptEnabled = true
        binding.youtubeWebview.loadUrl("https://www.youtube.com/embed/$videoId")
    }

    override fun loadCarousel(imageLinks: List<String>) {
        val adapter = ImageAdapter(this, imageLinks)
        binding.carouselPhoto.findViewById<ViewPager>(R.id.view_pager).adapter = adapter
    }

    override fun showReviews(reviews: List<Review>) {
        TODO("Not yet implemented")
    }

    override fun showEmptyReviews() {
        TODO("Not yet implemented")
    }

    override fun showDummyReviewItem(reviewItem: Map<String, String>) {
        TODO("Not yet implemented")
    }
}



