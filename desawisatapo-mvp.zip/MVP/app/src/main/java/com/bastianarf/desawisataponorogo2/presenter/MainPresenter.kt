package com.bastianarf.desawisataponorogo2.presenter

import android.util.Log
import com.bastianarf.desawisataponorogo2.view.activity.MainActivity
import com.bastianarf.desawisataponorogo2.view.contract.MainContract
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class MainPresenter(private val view: MainContract.View) : MainContract.Presenter {
    private val user = FirebaseAuth.getInstance().currentUser
    private val db = FirebaseFirestore.getInstance()

    override fun loadUserNickName() {
        if (user != null) {
            val docRef = db.collection("users").document(user.uid)
            docRef.get().addOnSuccessListener { document ->
                if (document != null) {
                    val nickName = document.getString("nickName")
                    if (nickName != null) {
                        view.showUserNickName(nickName)
                    }
                }
            }.addOnFailureListener { exception ->
                Log.d(MainActivity.TAG, "get failed with ", exception)
            }
        }
    }
}
