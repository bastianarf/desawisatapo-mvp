package com.bastianarf.desawisataponorogo2.presenter

import android.util.Patterns
import com.bastianarf.desawisataponorogo2.view.contract.LoginContract
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class LoginPresenter(private val view: LoginContract.View, private val auth: FirebaseAuth, private val firestore: FirebaseFirestore) : LoginContract.Presenter {

    override fun checkInputValidity(email: String, password: String) {
        val emailIsValid = Patterns.EMAIL_ADDRESS.matcher(email).matches()
        val passwordIsValid = password.length >= 8
        view.enableLoginButton(emailIsValid && passwordIsValid)
    }

    override fun signIn(email: String, password: String) {
        view.showLoading()
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                view.hideLoading()
                if (task.isSuccessful) {
                    view.showLoginSuccess()
                } else {
                    view.showLoginError(task.exception?.message ?: "Unknown error")
                }
            }
    }
}
