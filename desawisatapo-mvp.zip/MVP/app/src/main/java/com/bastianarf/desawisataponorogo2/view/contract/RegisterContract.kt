package com.bastianarf.desawisataponorogo2.view.contract

interface RegisterContract {
    interface View {
        fun showLoading()
        fun hideLoading()
        fun showRegistrationSuccess()
        fun showRegistrationError(message: String)
        fun enableRegisterButton(enable: Boolean)
        fun navigateToLogin()
    }

    interface Presenter {
        fun registerUser(email: String, password: String, fullName: String, nickName: String, bio: String, avatar: String)
        fun signOut()
    }
}
