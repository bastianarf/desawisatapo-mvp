package com.bastianarf.desawisataponorogo2.presenter

import android.net.Uri
import com.bastianarf.desawisataponorogo2.utilities.UserProfileResponse
import com.bastianarf.desawisataponorogo2.view.contract.EditInputBioContract
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.storage.FirebaseStorage
import java.io.File
import java.lang.ref.WeakReference

class EditInputBioPresenter(
    private val view: EditInputBioContract.View,
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val firebaseAuth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val storage: FirebaseStorage = FirebaseStorage.getInstance()
) : EditInputBioContract.Presenter {

    private val viewRef = WeakReference(view)

    override fun start() {
        getUserProfile()
    }

    override fun uploadImage(file: File, onSuccess: (String) -> Unit, onFailure: () -> Unit) {
        view.showLoading()
        val fileRef = storage.reference.child("avatar/${file.name}")
        val uploadTask = fileRef.putFile(Uri.fromFile(file))

        uploadTask.addOnFailureListener {
            view.hideLoading()
            view.showUploadFailure("Upload failed")
            onFailure()
        }.addOnSuccessListener {
            fileRef.downloadUrl.addOnSuccessListener { uri ->
                view.hideLoading()
                view.showUploadSuccess("Upload successful", uri.toString())
                onSuccess(uri.toString())
            }.addOnFailureListener {
                    view.hideLoading()
                    view.showUploadFailure("Failed to get download URL")
                    onFailure()
                }
        }
    }

    override fun getUserProfile() {
        val currentUser = firebaseAuth.currentUser
        currentUser?.let {
            val userId = it.uid
            val userRef = firestore.collection("users").document(userId)
            userRef.get().addOnSuccessListener { document ->
                if (document.exists()) {
                    val userProfile = document.toObject(UserProfileResponse::class.java)
                    userProfile?.let { profile ->
                        viewRef.get()?.showProfile(profile)
                    }
                }
            }
        }
    }

    override fun saveProfile(email: String, fullName: String, nickName: String, bio: String, file: File) {
        uploadImage(file, { photoUrl ->
            val userProfile = UserProfileResponse(email, fullName, nickName, bio, photoUrl)
            updateUserProfile(userProfile)
        },{
            view.showUploadFailure("Failed to upload image")
        })
    }

    private fun updateUserProfile(userProfile: UserProfileResponse) {
        val currentUser = firebaseAuth.currentUser
        currentUser?.let {
            val userId = it.uid
            val userRef = firestore.collection("users").document(userId)
            userRef.set(userProfile, SetOptions.merge())
                .addOnSuccessListener {
                    view.showToast("Profile updated successfully")
                    view.goToMainActivity()
                }
                .addOnFailureListener {
                    view.showToast("Profile update failed")
                }
        }
    }
}
