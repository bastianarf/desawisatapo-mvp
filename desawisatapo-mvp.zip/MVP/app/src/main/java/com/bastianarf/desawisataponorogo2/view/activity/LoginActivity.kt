package com.bastianarf.desawisataponorogo2.view.activity

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bastianarf.desawisataponorogo2.view.contract.LoginContract
import com.bastianarf.desawisataponorogo2.presenter.LoginPresenter
import com.bastianarf.desawisataponorogo2.databinding.ActivityLoginBinding
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase

class LoginActivity : AppCompatActivity(), LoginContract.View {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var presenter: LoginContract.Presenter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val auth = Firebase.auth
        val firestore = FirebaseFirestore.getInstance()
        presenter = LoginPresenter(this, auth, firestore)

        actionClick()
        inputValidity()
    }

    private fun inputValidity() {
        binding.etLoginEmail.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(s: Editable?) {
                val email = binding.etLoginEmail.text.toString()
                val password = binding.etLoginPassword.text.toString()
                presenter.checkInputValidity(email, password)
            }
        })

        binding.etLoginPassword.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

            override fun afterTextChanged(s: Editable?) {
                val email = binding.etLoginEmail.text.toString()
                val password = binding.etLoginPassword.text.toString()
                presenter.checkInputValidity(email, password)
            }
        })
    }

    private fun actionClick() {
        binding.toRegister.setOnClickListener {
            navigateToRegister()
        }
        binding.btnLogin.setOnClickListener {
            val email = binding.etLoginEmail.text.toString()
            val password = binding.etLoginPassword.text.toString()
            presenter.signIn(email, password)
        }
    }

    override fun showLoading() {
        // Show a loading indicator
    }

    override fun hideLoading() {
        // Hide the loading indicator
    }

    override fun showLoginSuccess() {
        // Handle successful login
        goToNextActivity()
    }

    override fun showLoginError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun enableLoginButton(enable: Boolean) {
        binding.btnLogin.isEnabled = enable
    }

    override fun navigateToRegister() {
        val intent = Intent(this, RegisterActivity::class.java)
        startActivity(intent)
    }

    private fun goToNextActivity() {
        val user = Firebase.auth.currentUser
        user?.let { currentUser ->
            val userId = currentUser.uid
            val userRef = FirebaseFirestore.getInstance().collection("users").document(userId)
            userRef.get()
                .addOnSuccessListener { documentSnapshot ->
                    val bio = documentSnapshot.getString("bio")
                    val avatar = documentSnapshot.getString("avatar")
                    val intent = if (bio.isNullOrEmpty() && avatar.isNullOrEmpty()) {
                        Intent(this, InputBioActivity::class.java)
                    } else {
                        Intent(this, MainActivity::class.java)
                    }
                    startActivity(intent)
                    finish()
                }
                .addOnFailureListener { exception ->
                    Toast.makeText(this, "Error: ${exception.message}", Toast.LENGTH_SHORT).show()
                }
        }
    }

    override fun onStart() {
        super.onStart()
        val currentUser = Firebase.auth.currentUser
        if (currentUser != null) {
            goToNextActivity()
        }
    }

    companion object {
        private const val TAG = "LoginActivity"
    }
}
