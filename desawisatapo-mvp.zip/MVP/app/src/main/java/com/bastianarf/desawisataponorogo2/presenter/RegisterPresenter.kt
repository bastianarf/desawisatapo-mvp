package com.bastianarf.desawisataponorogo2.presenter

import com.bastianarf.desawisataponorogo2.view.contract.RegisterContract
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class RegisterPresenter(private val view: RegisterContract.View, private val auth: FirebaseAuth, private val firestore: FirebaseFirestore) : RegisterContract.Presenter {

    override fun registerUser(email: String, password: String, fullName: String, nickName: String, bio: String, avatar: String) {
        view.showLoading()
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                view.hideLoading()
                if (task.isSuccessful) {
                    val user = auth.currentUser
                    val userValues = hashMapOf(
                        "email" to email,
                        "fullName" to fullName,
                        "nickName" to nickName,
                        "bio" to bio,
                        "avatar" to avatar
                    )

                    firestore.collection("users").document(user?.uid!!)
                        .set(userValues)
                        .addOnSuccessListener {
                            view.showRegistrationSuccess()
                        }
                        .addOnFailureListener { exception ->
                            view.showRegistrationError(exception.message ?: "Unknown error")
                        }
                } else {
                    view.showRegistrationError(task.exception?.message ?: "Unknown error")
                }
            }
    }

    override fun signOut() {
        auth.signOut()
    }
}
