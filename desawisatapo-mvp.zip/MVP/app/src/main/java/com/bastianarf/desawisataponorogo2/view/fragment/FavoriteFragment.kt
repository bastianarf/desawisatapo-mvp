package com.bastianarf.desawisataponorogo2.view.fragment

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.bastianarf.desawisataponorogo2.adapters.MainAdapter
import com.bastianarf.desawisataponorogo2.databinding.FragmentFavoriteBinding
import com.bastianarf.desawisataponorogo2.utilities.Content
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class FavoriteFragment : Fragment(){

    private var _binding : FragmentFavoriteBinding? = null
    private val binding get() = _binding!!

    // get current user
    val firebaseAuth = FirebaseAuth.getInstance()
    val currentUser = firebaseAuth.currentUser

    // initialize firestore database and fetch user's data that currently login in this app
    @SuppressLint("StaticFieldLeak")
    val db = FirebaseFirestore.getInstance()

    private var rowItems = ArrayList<Content>()
    private var contents = mutableListOf<Content>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFavoriteBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val recyclerViewFavoriteContent = binding.rvFavorite
        recyclerViewFavoriteContent.layoutManager = LinearLayoutManager(context)
        fillingTheFavorite()
    }

    private fun fillingTheFavorite(){
        // Fetch data from Firestore and update the adapter
        val favoriteList = FirebaseFirestore.getInstance().collection("contents").whereArrayContains("favorite",
            currentUser?.uid!!
        )
        favoriteList.get()
            .addOnSuccessListener { documents ->
                for (document in documents) {
                    val content = document.toObject(Content::class.java)
                    content.documentId = document.id
                    contents.add(content)
                    Log.d("konten", content.toString())
                }
                val mainAdapter = MainAdapter(requireContext(), contents)
                Log.d("DATAA", contents.toString())
                // Set the adapter of the RecyclerView to the FavoriteAdapter instance.
                binding.rvFavorite.adapter = mainAdapter
            }
            .addOnFailureListener { exception ->
                Log.d("konten", "get failed with : ", exception)
            }
    }
}