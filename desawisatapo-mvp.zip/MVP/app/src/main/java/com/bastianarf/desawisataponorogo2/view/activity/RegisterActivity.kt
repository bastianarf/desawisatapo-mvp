package com.bastianarf.desawisataponorogo2.view.activity

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.bastianarf.desawisataponorogo2.R
import com.bastianarf.desawisataponorogo2.view.contract.RegisterContract
import com.bastianarf.desawisataponorogo2.presenter.RegisterPresenter
import com.bastianarf.desawisataponorogo2.databinding.ActivityRegisterBinding
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase

class RegisterActivity : AppCompatActivity(), RegisterContract.View {

    private lateinit var binding: ActivityRegisterBinding
    private lateinit var presenter: RegisterContract.Presenter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val auth = Firebase.auth
        val firestore = FirebaseFirestore.getInstance()
        presenter = RegisterPresenter(this, auth, firestore)

        actionClick()
    }

    private fun actionClick() {
        binding.btnRegister.setOnClickListener {
            val fullName = binding.etRegisterFullname.text.toString()
            val nickName = binding.etRegisterNickname.text.toString()
            val email = binding.etRegisterEmail.text.toString()
            val password = binding.etRegisterPassword.text.toString()
            val confirmPassword = binding.etConfirmPassword.text.toString()
            val bio = ""
            val avatar = ""

            if (password == confirmPassword) {
                when {
                    fullName.isEmpty() -> {
                        binding.registerFullnameLayout.error = "Masukkan Nama Lengkap"
                    }
                    nickName.isEmpty() -> {
                        binding.registerNicknameLayout.error = "Masukkan nickname"
                    }
                    email.isEmpty() -> {
                        binding.registerEmailLayout.error = "Masukkan Email"
                    }
                    password.isEmpty() -> {
                        binding.registerPasswordLayout.error = "Masukkan Password"
                    }
                    confirmPassword.isEmpty() -> {
                        binding.confirmPasswordLayout.error = "Masukkan konfirmasi password"
                    }
                    else -> {
                        presenter.registerUser(email, password, fullName, nickName, bio, avatar)
                    }
                }
            } else {
                binding.confirmPasswordLayout.error = getString(R.string.error_confirm_password)
            }
        }
        binding.toLogin.setOnClickListener {
            navigateToLogin()
        }
    }

    override fun showLoading() {
        // Show a loading indicator
    }

    override fun hideLoading() {
        // Hide the loading indicator
    }

    override fun showRegistrationSuccess() {
        AlertDialog.Builder(this).apply {
            setTitle("Registrasi Berhasil")
            setMessage("Kembali ke halaman Sign In")
            setPositiveButton("Ok") { _, _ ->
                presenter.signOut()
                navigateToLogin()
                finish()
            }
            create()
            show()
        }
    }

    override fun showRegistrationError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun enableRegisterButton(enable: Boolean) {
        binding.btnRegister.isEnabled = enable
    }

    override fun navigateToLogin() {
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
        finish()
    }
}