package com.bastianarf.desawisataponorogo2.view.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bastianarf.desawisataponorogo2.R
import com.bastianarf.desawisataponorogo2.adapters.AddReviewAdapter
import com.bastianarf.desawisataponorogo2.adapters.ReviewAdapter
import com.bastianarf.desawisataponorogo2.presenter.DetailPresenter
import com.bastianarf.desawisataponorogo2.utilities.Review
import com.bastianarf.desawisataponorogo2.view.contract.DetailContract
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class DetailFragment : Fragment(), DetailContract.View {

    private lateinit var presenter: DetailPresenter
    private lateinit var tvEmpty: TextView
    private lateinit var reviewAdapter: ReviewAdapter
    private lateinit var addReviewAdapter: AddReviewAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            val contentId = it.getString("contentId")
            presenter = DetailPresenter(this, FirebaseFirestore.getInstance(), FirebaseAuth.getInstance())
            presenter.onCreate(contentId)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_detail, container, false)

        tvEmpty = view.findViewById(R.id.tv_empty)

        val rvAddReview: RecyclerView = view.findViewById(R.id.rv_add_review)
        rvAddReview.layoutManager = LinearLayoutManager(context)
        addReviewAdapter = AddReviewAdapter { reviewText ->
            handleReviewSubmission(reviewText)
        }
        rvAddReview.adapter = addReviewAdapter
        presenter.addDummyReviewItem()

        val rvReviews: RecyclerView = view.findViewById(R.id.rv_reviews)
        rvReviews.layoutManager = LinearLayoutManager(context)
        rvReviews.minimumHeight = 350
        reviewAdapter = ReviewAdapter(requireContext(), mutableListOf())
        rvReviews.adapter = reviewAdapter

        presenter.fetchReviews()

        return view
    }

    private fun handleReviewSubmission(reviewText: String) {
        presenter.addReview(reviewText)
    }

    override fun showTitle(title: String) {
        // Not applicable for fragment
    }

    override fun showFavorite(isFavorite: Boolean) {
        // Not applicable for fragment
    }

    override fun showToast(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }

    override fun showDummyReviewItem(reviewItem: Map<String, String>) {
        addReviewAdapter.addReviewItem(reviewItem)
    }


    override fun updateFavoriteIcon() {
        // Not applicable for fragment
    }

    override fun showCategories(categories: String) {
        // Not applicable for fragment
    }

    override fun setCategoryBackground(category: String) {
        // Not applicable for fragment
    }

    override fun showDescription(description: String) {
        // Not applicable for fragment
    }

    override fun loadYoutubeVideo(videoId: String?) {
        // Not applicable for fragment
    }

    override fun loadCarousel(imageLinks: List<String>) {
        // Not applicable for fragment
    }

    override fun showReviews(reviews: List<Review>) {
        reviewAdapter.updateList(reviews as MutableList<Review>)
        tvEmpty.visibility = View.GONE
    }

    override fun showEmptyReviews() {
        tvEmpty.visibility = View.VISIBLE
    }
}






