package com.bastianarf.desawisataponorogo2.view.contract

interface LoginContract {
    interface View {
        fun showLoading()
        fun hideLoading()
        fun showLoginSuccess()
        fun showLoginError(message: String)
        fun enableLoginButton(enable: Boolean)
        fun navigateToRegister()
    }

    interface Presenter {
        fun checkInputValidity(email: String, password: String)
        fun signIn(email: String, password: String)
    }
}
