package com.bastianarf.desawisataponorogo2.response

data class Reviews(
    val userId : String = "",
    val reviewId : String = "",
    val review : String = ""
)