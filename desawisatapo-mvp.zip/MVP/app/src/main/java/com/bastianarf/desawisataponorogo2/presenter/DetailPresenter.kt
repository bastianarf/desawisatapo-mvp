package com.bastianarf.desawisataponorogo2.presenter

import android.util.Log
import com.bastianarf.desawisataponorogo2.utilities.Content
import com.bastianarf.desawisataponorogo2.utilities.Review
import com.bastianarf.desawisataponorogo2.view.contract.DetailContract
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import java.util.UUID

class DetailPresenter(
    private val view: DetailContract.View,
    private val firestore: FirebaseFirestore,
    private val firebaseAuth: FirebaseAuth
) : DetailContract.Presenter {

    private var documentId: String? = null
    private var isFavorite = false

    override fun onCreate(documentId: String?) {
        this.documentId = documentId
        fetchData()
    }

    private fun fetchData() {
        val user = firebaseAuth.currentUser
        if (user != null && documentId != null) {
            val docRef = firestore.collection("contents").document(documentId!!)
            docRef.get().addOnSuccessListener { document ->
                if (document != null) {
                    val title = document.getString("name")
                    view.showTitle(title ?: "")
                    isFavorite = document.get("favorite")?.let {
                        (it as? List<*>)?.contains(user.uid) ?: false
                    } ?: false
                    view.updateFavoriteIcon()

                    val itemDetail = document.toObject(Content::class.java)
                    view.showCategories(itemDetail?.categories ?: "")
                    view.setCategoryBackground(itemDetail?.categories ?: "")
                    view.showDescription(itemDetail?.description ?: "")
                    view.loadYoutubeVideo(extractYoutubeVideoId(itemDetail?.youtubeLink))

                    val gallery = document.get("gallery") as List<Map<String, String>>
                    val imageLinks = gallery.map { it["link"]!! }
                    view.loadCarousel(imageLinks)

                    val favorites = document.get("favorite") as? MutableList<String>
                    if (favorites == null) {
                        docRef.update("favorite", mutableListOf<String>())
                    }

                    isFavorite = favorites?.contains(user.uid) == true
                    view.updateFavoriteIcon()
                }
            }
        }
    }

    override fun onFavoriteClicked() {
        val user = firebaseAuth.currentUser
        if (user != null && documentId != null) {
            val docRef = firestore.collection("contents").document(documentId!!)
            firestore.runTransaction { transaction ->
                val snapshot = transaction.get(docRef)
                val favorites = snapshot.get("favorite") as? MutableList<String> ?: mutableListOf()
                if (favorites.contains(user.uid)) {
                    favorites.remove(user.uid)
                    isFavorite = false
                } else {
                    favorites.add(user.uid)
                    isFavorite = true
                }
                transaction.update(docRef, "favorite", favorites)
            }.addOnSuccessListener {
                val message = if (isFavorite) {
                    "Marked as favorite"
                } else {
                    "Removed from favorites"
                }
                view.showToast(message)
                view.updateFavoriteIcon()
            }.addOnFailureListener { e ->
                Log.w("DetailPresenter", "Transaction failure", e)
            }
        }
    }

    private fun extractYoutubeVideoId(youtubeLink: String?): String? {
        val youtubePatterns = listOf(
            "youtu.be/([a-zA-Z0-9_-]+)",
            "youtube.com/watch\\?v=([a-zA-Z0-9_-]+)",
            "youtube.com/embed/([a-zA-Z0-9_-]+)",
            "youtube.com/v/([a-zA-Z0-9_-]+)"
        )

        youtubeLink?.let {
            for (pattern in youtubePatterns) {
                val regex = Regex(pattern)
                val matchResult = regex.find(it)
                if (matchResult != null) {
                    return matchResult.groupValues[1]
                }
            }
        }
        return null
    }

    override fun fetchReviews() {
        if (documentId != null) {
            val contentRef = firestore.collection("contents").document(documentId!!)
            contentRef.get().addOnSuccessListener { documentSnapshot ->
                if (documentSnapshot.exists()) {
                    val reviews = documentSnapshot.get("reviews") as? List<Map<String, String>>
                    if (!reviews.isNullOrEmpty()) {
                        val reviewList = mutableListOf<Review>()
                        for (reviewMap in reviews) {
                            val userId = reviewMap["userId"] ?: ""
                            val reviewId = reviewMap["reviewId"] ?: ""
                            val reviewText = reviewMap["reviewText"] ?: ""

                            firestore.collection("users").document(userId).get().addOnSuccessListener { userSnapshot ->
                                if (userSnapshot.exists()) {
                                    val fullName = userSnapshot.getString("fullName") ?: ""
                                    val avatar = userSnapshot.getString("avatar")
                                    val review = Review(userId, fullName, avatar, reviewId, reviewText)
                                    reviewList.add(review)

                                    if (reviewList.size == reviews.size) {
                                        view.showReviews(reviewList)
                                    }
                                }
                            }
                        }
                    } else {
                        view.showEmptyReviews()
                    }
                }
            }.addOnFailureListener { e ->
                Log.w("DetailPresenter", "Error fetching reviews", e)
            }
        }
    }

    override fun addReview(reviewText: String) {
        val user = firebaseAuth.currentUser
        if (user != null && documentId != null) {
            val reviewId = UUID.randomUUID().toString()
            val review = hashMapOf(
                "userId" to user.uid,
                "reviewId" to reviewId,
                "reviewText" to reviewText
            )

            val contentRef = firestore.collection("contents").document(documentId!!)
            contentRef.update("reviews", FieldValue.arrayUnion(review))
                .addOnSuccessListener {
                    view.showToast("Review added successfully")
                    fetchReviews()
                }
                .addOnFailureListener { e ->
                    Log.w("DetailPresenter", "Error adding review", e)
                }
        }
    }

    override fun addDummyReviewItem() {
        val firebaseAuth = FirebaseAuth.getInstance()
        val user = firebaseAuth.currentUser

        user?.let {
            val dummyReviewItem = mapOf(
                "userId" to user.uid,
                "reviewText" to "Masukkan Review"
            )
            view.showDummyReviewItem(dummyReviewItem)
        }
    }
}


