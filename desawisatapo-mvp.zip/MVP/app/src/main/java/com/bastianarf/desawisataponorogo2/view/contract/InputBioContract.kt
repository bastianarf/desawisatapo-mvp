package com.bastianarf.desawisataponorogo2.view.contract

import java.io.File

interface InputBioContract {
    interface View {
        fun showUploadSuccess()
        fun showUploadFailure(message: String)
        fun showLoading(isLoading: Boolean)
        fun setThumbnailImage(file: File)
        fun resetThumbnailImage()
    }

    interface Presenter {
        fun uploadImage(userId: String, file: File, bio: String)
        fun setFile(file: File)
        fun start()
    }
}
